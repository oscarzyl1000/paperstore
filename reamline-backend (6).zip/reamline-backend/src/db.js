const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, 'reamline.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    company TEXT,
    phone TEXT,
    address TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS stores (
    id TEXT PRIMARY KEY,
    owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    banner_color TEXT DEFAULT '#8B6A4F',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    store_id TEXT NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    gsm TEXT,
    unit TEXT NOT NULL,
    price_kobo INTEGER NOT NULL,
    color TEXT,
    description TEXT,
    active INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS riders (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    vehicle TEXT,
    zone TEXT,
    status TEXT DEFAULT 'available', -- available | busy
    deliveries INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS payment_methods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    brand TEXT NOT NULL,
    last4 TEXT NOT NULL,
    exp TEXT NOT NULL,
    is_default INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    store_id TEXT REFERENCES stores(id),
    status TEXT NOT NULL DEFAULT 'Processing', -- Processing | Out for delivery | Delivered
    rider_id TEXT REFERENCES riders(id),
    payment_method TEXT NOT NULL, -- 'card:<id>' or 'cod'
    subtotal_kobo INTEGER NOT NULL,
    delivery_kobo INTEGER NOT NULL,
    total_kobo INTEGER NOT NULL,
    delivery_address TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id TEXT NOT NULL REFERENCES products(id),
    product_name TEXT NOT NULL,
    unit_price_kobo INTEGER NOT NULL,
    quantity INTEGER NOT NULL
  );
`);

function seedIfEmpty() {
  const storeCount = db.prepare('SELECT COUNT(*) AS c FROM stores').get().c;
  if (storeCount === 0) {
    // Platform's own store, plus two example third-party seller stores so the
    // marketplace directory isn't empty on a fresh install. Each seller store
    // is owned by a real (demo) user account so you can log in as that seller
    // and manage it — see the printed credentials in the seed log below.
    const bootstrapOwner = db.prepare(`
      INSERT INTO users (name, email, password_hash, company, phone, address)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run('Reamline Team', 'stores@reamline.com', bcrypt.hashSync('reamline-owns-this', 10), 'Reamline Paper Supply Co.', '', '');

    const sellerA = db.prepare(`
      INSERT INTO users (name, email, password_hash, company, phone, address)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run('Chidi Nwosu', 'chidi@lekkicraft.com', bcrypt.hashSync('seller1234', 10), 'Lekki Craft Papers', '070 2233 4455', '12 Admiralty Way, Lekki Phase 1, Lagos');

    const sellerB = db.prepare(`
      INSERT INTO users (name, email, password_hash, company, phone, address)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run('Grace Okafor', 'grace@naijapack.com', bcrypt.hashSync('seller1234', 10), 'Naija Packaging Co', '081 9988 7766', '5 Wharf Road, Apapa, Lagos');

    const insertStore = db.prepare(`
      INSERT INTO stores (id, owner_id, name, description, banner_color) VALUES (?, ?, ?, ?, ?)
    `);
    insertStore.run('reamline', bootstrapOwner.lastInsertRowid, 'Reamline Direct', 'Our own core stock — office paper, cardstock and packaging rolls, dispatched same-day.', '#1E3A5F');
    insertStore.run('lekki-craft', sellerA.lastInsertRowid, 'Lekki Craft Papers', 'Specialty and decorative paper for stationers, gift wrappers and craft studios.', '#B23A2E');
    insertStore.run('naija-pack', sellerB.lastInsertRowid, 'Naija Packaging Co', 'Bulk packaging and food-safe wrap for bakeries, vendors and small manufacturers.', '#4C7A4A');

    console.log('Seeded demo seller accounts — chidi@lekkicraft.com / seller1234, grace@naijapack.com / seller1234');
  }

  const productCount = db.prepare('SELECT COUNT(*) AS c FROM products').get().c;
  if (productCount === 0) {
    const insert = db.prepare(`
      INSERT INTO products (id, store_id, name, category, gsm, unit, price_kobo, color, description)
      VALUES (@id, @store_id, @name, @category, @gsm, @unit, @price_kobo, @color, @description)
    `);
    const products = [
      { id: 'p1', store_id: 'reamline', name: 'A4 Bond Paper 80gsm', category: 'office', gsm: '80gsm', unit: 'ream of 500', price_kobo: 820000, color: '#F2EEE3', description: 'Bright white, laser & inkjet friendly. Standard office stock.' },
      { id: 'p2', store_id: 'reamline', name: 'A4 Photocopy 70gsm', category: 'office', gsm: '70gsm', unit: 'ream of 500', price_kobo: 690000, color: '#EEEAE0', description: 'Everyday copy paper for high-volume printing.' },
      { id: 'p3', store_id: 'reamline', name: 'A3 Cardstock 250gsm', category: 'craft', gsm: '250gsm', unit: 'pack of 100', price_kobo: 990000, color: '#E6DCC8', description: 'Heavy stock for covers, invitations and signage.' },
      { id: 'p6', store_id: 'reamline', name: 'Thermal Receipt Rolls', category: 'office', gsm: '55gsm', unit: 'box of 20', price_kobo: 1560000, color: '#F5F3EE', description: '80mm POS rolls, BPA-free coating.' },
      { id: 'p7', store_id: 'lekki-craft', name: 'A4 Colour Paper Mix', category: 'craft', gsm: '80gsm', unit: 'ream of 250', price_kobo: 780000, color: '#E7CBB0', description: 'Assorted pastel shades for flyers and crafts.' },
      { id: 'p9', store_id: 'lekki-craft', name: 'Marbled Gift Wrap Sheets', category: 'craft', gsm: '120gsm', unit: 'pack of 25', price_kobo: 640000, color: '#D8B4A0', description: 'Hand-marbled decorative sheets for gift wrapping and bookbinding.' },
      { id: 'p4', store_id: 'naija-pack', name: 'Kraft Paper Roll', category: 'packaging', gsm: '90gsm', unit: '1m x 50m roll', price_kobo: 1250000, color: '#B98A5E', description: 'Natural brown wrapping and packaging roll.' },
      { id: 'p5', store_id: 'naija-pack', name: 'Newsprint Roll', category: 'packaging', gsm: '45gsm', unit: '0.9m x 40m roll', price_kobo: 740000, color: '#D9D2BE', description: 'Lightweight roll for wrapping and void fill.' },
      { id: 'p8', store_id: 'naija-pack', name: 'Greaseproof Sheets', category: 'packaging', gsm: '40gsm', unit: 'pack of 500', price_kobo: 1120000, color: '#EFE7D2', description: 'Food-safe wrap sheets for bakeries and vendors.' }
    ];
    const insertMany = db.transaction((rows) => rows.forEach((r) => insert.run(r)));
    insertMany(products);
  }

  const riderCount = db.prepare('SELECT COUNT(*) AS c FROM riders').get().c;
  if (riderCount === 0) {
    const insert = db.prepare(`
      INSERT INTO riders (id, name, vehicle, zone, status, deliveries)
      VALUES (@id, @name, @vehicle, @zone, @status, @deliveries)
    `);
    const riders = [
      { id: 'r1', name: 'Tunde Bakare', vehicle: 'Okada · Bike', zone: 'Victoria Island', status: 'available', deliveries: 412 },
      { id: 'r2', name: 'Ifeoma Chukwu', vehicle: 'Van', zone: 'Ikeja / Mainland', status: 'busy', deliveries: 298 },
      { id: 'r3', name: 'Musa Danladi', vehicle: 'Okada · Bike', zone: 'Lekki', status: 'available', deliveries: 187 },
      { id: 'r4', name: 'Grace Effiong', vehicle: 'Van', zone: 'Surulere', status: 'available', deliveries: 356 },
      { id: 'r5', name: 'Chinedu Obi', vehicle: 'Okada · Bike', zone: 'Yaba', status: 'busy', deliveries: 229 },
      { id: 'r6', name: 'Blessing Eze', vehicle: 'Tricycle · Keke', zone: 'Apapa', status: 'available', deliveries: 141 }
    ];
    const insertMany = db.transaction((rows) => rows.forEach((r) => insert.run(r)));
    insertMany(riders);
  }

  const demoCustomer = db.prepare('SELECT id FROM users WHERE email = ?').get('demo@reamline.com');
  if (!demoCustomer) {
    const hash = bcrypt.hashSync('demo1234', 10);
    const info = db.prepare(`
      INSERT INTO users (name, email, password_hash, company, phone, address)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run('Adaeze Umeh', 'demo@reamline.com', hash, 'Umeh Print & Copy', '080 1234 5678', '14 Adeola Odeku St, Victoria Island, Lagos');

    db.prepare(`
      INSERT INTO payment_methods (user_id, brand, last4, exp, is_default) VALUES (?, ?, ?, ?, ?)
    `).run(info.lastInsertRowid, 'Verve', '4821', '09/28', 1);
    db.prepare(`
      INSERT INTO payment_methods (user_id, brand, last4, exp, is_default) VALUES (?, ?, ?, ?, ?)
    `).run(info.lastInsertRowid, 'Mastercard', '0099', '03/27', 0);
  }
}

seedIfEmpty();

module.exports = db;
