const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM payment_methods WHERE user_id = ? ORDER BY is_default DESC, created_at DESC').all(req.userId);
  res.json({ paymentMethods: rows });
});

router.post('/', (req, res) => {
  const { number, exp, brand } = req.body || {};
  if (!number || !exp) {
    return res.status(400).json({ error: 'Card number and expiry are required.' });
  }
  // NOTE: this is a demo. Never store raw card numbers in a real system —
  // integrate a real payment processor (Stripe, Paystack, Flutterwave, etc.)
  // and store only the token/last4 it returns.
  const last4 = number.replace(/\s/g, '').slice(-4);
  const info = db.prepare(`
    INSERT INTO payment_methods (user_id, brand, last4, exp, is_default) VALUES (?, ?, ?, ?, 0)
  `).run(req.userId, brand || 'Card', last4, exp);
  const row = db.prepare('SELECT * FROM payment_methods WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ paymentMethod: row });
});

router.delete('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM payment_methods WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!row) return res.status(404).json({ error: 'Payment method not found.' });
  db.prepare('DELETE FROM payment_methods WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

router.put('/:id/default', (req, res) => {
  const row = db.prepare('SELECT * FROM payment_methods WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!row) return res.status(404).json({ error: 'Payment method not found.' });
  const tx = db.transaction(() => {
    db.prepare('UPDATE payment_methods SET is_default = 0 WHERE user_id = ?').run(req.userId);
    db.prepare('UPDATE payment_methods SET is_default = 1 WHERE id = ?').run(req.params.id);
  });
  tx();
  res.json({ ok: true });
});

module.exports = router;
