const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function withStore(p) {
  const store = db.prepare('SELECT id, name, banner_color FROM stores WHERE id = ?').get(p.store_id);
  return { ...p, store: store ? { id: store.id, name: store.name, bannerColor: store.banner_color } : null };
}

router.get('/', (req, res) => {
  const { category, store } = req.query;
  let sql = 'SELECT * FROM products WHERE active = 1';
  const params = [];
  if (category && category !== 'all') { sql += ' AND category = ?'; params.push(category); }
  if (store && store !== 'all') { sql += ' AND store_id = ?'; params.push(store); }
  const rows = db.prepare(sql).all(...params);
  res.json({ products: rows.map(withStore) });
});

// Edit a product you own (via your store)
router.put('/:id', requireAuth, (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(product.store_id);
  if (!store || store.owner_id !== req.userId) return res.status(403).json({ error: 'You do not own this product.' });

  const { name, category, gsm, unit, priceKobo, color, description } = req.body || {};
  db.prepare(`
    UPDATE products SET name = COALESCE(?, name), category = COALESCE(?, category), gsm = COALESCE(?, gsm),
      unit = COALESCE(?, unit), price_kobo = COALESCE(?, price_kobo), color = COALESCE(?, color),
      description = COALESCE(?, description) WHERE id = ?
  `).run(name, category, gsm, unit, priceKobo ? Math.round(Number(priceKobo)) : null, color, description, product.id);

  res.json({ product: withStore(db.prepare('SELECT * FROM products WHERE id = ?').get(product.id)) });
});

// Deactivate (soft-delete) a product you own
router.delete('/:id', requireAuth, (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(product.store_id);
  if (!store || store.owner_id !== req.userId) return res.status(403).json({ error: 'You do not own this product.' });

  db.prepare('UPDATE products SET active = 0 WHERE id = ?').run(product.id);
  res.status(204).end();
});

module.exports = router;
