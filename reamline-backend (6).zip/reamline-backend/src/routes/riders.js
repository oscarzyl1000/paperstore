const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Public fleet listing — used on the Riders & Delivery tab
router.get('/', (req, res) => {
  const { status } = req.query;
  const rows = status && status !== 'all'
    ? db.prepare('SELECT * FROM riders WHERE status = ?').all(status)
    : db.prepare('SELECT * FROM riders').all();
  res.json({ riders: rows });
});

// Live tracking for the logged-in user's active deliveries
router.get('/my-deliveries', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT o.id AS order_id, o.status, o.created_at, r.name AS rider_name, r.vehicle, r.zone
    FROM orders o
    LEFT JOIN riders r ON r.id = o.rider_id
    WHERE o.user_id = ? AND o.status != 'Delivered'
    ORDER BY o.created_at DESC
  `).all(req.userId);
  res.json({ deliveries: rows });
});

module.exports = router;
