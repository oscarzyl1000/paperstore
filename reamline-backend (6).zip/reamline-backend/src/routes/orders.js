const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

const DELIVERY_FEE_KOBO = 150000; // ₦1,500 flat delivery fee, charged per seller order

function serializeOrder(order) {
  const items = db.prepare(`
    SELECT product_id, product_name, unit_price_kobo, quantity FROM order_items WHERE order_id = ?
  `).all(order.id);
  const rider = order.rider_id
    ? db.prepare('SELECT id, name, vehicle, zone FROM riders WHERE id = ?').get(order.rider_id)
    : null;
  const store = order.store_id
    ? db.prepare('SELECT id, name FROM stores WHERE id = ?').get(order.store_id)
    : null;
  return {
    id: order.id,
    status: order.status,
    paymentMethod: order.payment_method,
    subtotalKobo: order.subtotal_kobo,
    deliveryKobo: order.delivery_kobo,
    totalKobo: order.total_kobo,
    deliveryAddress: order.delivery_address,
    createdAt: order.created_at,
    rider,
    store,
    items: items.map(i => ({
      productId: i.product_id, name: i.product_name,
      unitPriceKobo: i.unit_price_kobo, quantity: i.quantity
    }))
  };
}

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').all(req.userId);
  res.json({ orders: rows.map(serializeOrder) });
});

router.get('/:id', (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  res.json({ order: serializeOrder(order) });
});

// Checkout: body = { items: [{ productId, quantity }], paymentMethodId | 'cod' }
// A cart can span multiple sellers' stores — this splits it into one order
// per store, each assigned its own rider and charged its own delivery fee,
// the way a real multi-vendor marketplace fulfills orders.
router.post('/', (req, res) => {
  const { items, paymentMethodId } = req.body || {};
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Cart is empty.' });
  }
  if (!paymentMethodId) {
    return res.status(400).json({ error: 'Choose a payment method.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  if (!user.address) {
    return res.status(400).json({ error: 'Add a delivery address to your account before checking out.' });
  }

  let paymentLabel = 'cod';
  if (paymentMethodId !== 'cod') {
    const pm = db.prepare('SELECT * FROM payment_methods WHERE id = ? AND user_id = ?').get(paymentMethodId, req.userId);
    if (!pm) return res.status(400).json({ error: 'Payment method not found.' });
    paymentLabel = `card:${pm.id}`;
  }

  // Resolve product prices (and owning store) server-side — never trust client-submitted prices
  const productRows = db.prepare(
    `SELECT * FROM products WHERE id IN (${items.map(() => '?').join(',')}) AND active = 1`
  ).all(...items.map(i => i.productId));
  const productMap = Object.fromEntries(productRows.map(p => [p.id, p]));

  // Group requested line items by the store that sells them
  const byStore = {};
  for (const it of items) {
    const p = productMap[it.productId];
    const qty = Number(it.quantity) || 0;
    if (!p || qty <= 0) {
      return res.status(400).json({ error: `Invalid item in cart: ${it.productId}` });
    }
    if (!byStore[p.store_id]) byStore[p.store_id] = [];
    byStore[p.store_id].push({ productId: p.id, name: p.name, unitPrice: p.price_kobo, qty });
  }

  const createdOrders = [];

  const tx = db.transaction(() => {
    for (const [storeId, lineItems] of Object.entries(byStore)) {
      const subtotal = lineItems.reduce((sum, li) => sum + li.unitPrice * li.qty, 0);
      const total = subtotal + DELIVERY_FEE_KOBO;

      // Auto-assign the least-busy available rider (round-robin by fewest deliveries)
      const rider = db.prepare(`SELECT * FROM riders WHERE status = 'available' ORDER BY deliveries ASC LIMIT 1`).get()
        || db.prepare('SELECT * FROM riders ORDER BY deliveries ASC LIMIT 1').get();

      const orderId = 'RL-' + Math.floor(10000 + Math.random() * 89999);

      db.prepare(`
        INSERT INTO orders (id, user_id, store_id, status, rider_id, payment_method, subtotal_kobo, delivery_kobo, total_kobo, delivery_address)
        VALUES (?, ?, ?, 'Processing', ?, ?, ?, ?, ?, ?)
      `).run(orderId, req.userId, storeId, rider ? rider.id : null, paymentLabel, subtotal, DELIVERY_FEE_KOBO, total, user.address);

      const insertItem = db.prepare(`
        INSERT INTO order_items (order_id, product_id, product_name, unit_price_kobo, quantity)
        VALUES (?, ?, ?, ?, ?)
      `);
      lineItems.forEach(li => insertItem.run(orderId, li.productId, li.name, li.unitPrice, li.qty));

      if (rider) {
        db.prepare(`UPDATE riders SET status = 'busy' WHERE id = ?`).run(rider.id);
      }

      createdOrders.push(orderId);
    }
  });
  tx();

  const orders = createdOrders.map(id => serializeOrder(db.prepare('SELECT * FROM orders WHERE id = ?').get(id)));
  res.status(201).json({ orders });
});

// Advance an order's status (demo endpoint — in production this would be
// driven by rider app / webhook, not the customer).
router.put('/:id/status', (req, res) => {
  const { status } = req.body || {};
  const allowed = ['Processing', 'Out for delivery', 'Delivered'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `Status must be one of: ${allowed.join(', ')}` });
  }
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const tx = db.transaction(() => {
    db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, req.params.id);
    if (status === 'Delivered' && order.rider_id) {
      db.prepare(`UPDATE riders SET status = 'available', deliveries = deliveries + 1 WHERE id = ?`).run(order.rider_id);
    }
  });
  tx();

  res.json({ order: serializeOrder(db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id)) });
});

module.exports = router;
