const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function slugify(name) {
  const base = name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  let id = base || 'store';
  let n = 1;
  while (db.prepare('SELECT 1 FROM stores WHERE id = ?').get(id)) {
    id = `${base}-${++n}`;
  }
  return id;
}

function serializeStore(store) {
  const productCount = db.prepare('SELECT COUNT(*) AS c FROM products WHERE store_id = ? AND active = 1').get(store.id).c;
  const owner = db.prepare('SELECT name, company FROM users WHERE id = ?').get(store.owner_id);
  return {
    id: store.id,
    name: store.name,
    description: store.description,
    bannerColor: store.banner_color,
    ownerName: owner ? owner.name : null,
    productCount,
    createdAt: store.created_at
  };
}

// Public: browse all stores in the marketplace
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM stores ORDER BY created_at ASC').all();
  res.json({ stores: rows.map(serializeStore) });
});

// The current user's own store, if they have one (used to show "My Store" in Account)
router.get('/mine', requireAuth, (req, res) => {
  const store = db.prepare('SELECT * FROM stores WHERE owner_id = ?').get(req.userId);
  res.json({ store: store ? serializeStore(store) : null });
});

// Public: a single store's page, with its active product catalog
router.get('/:id', (req, res) => {
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(req.params.id);
  if (!store) return res.status(404).json({ error: 'Store not found.' });
  const products = db.prepare('SELECT * FROM products WHERE store_id = ? AND active = 1').all(store.id);
  res.json({ store: serializeStore(store), products });
});

// Create a new seller store for the current user (one store per account)
router.post('/', requireAuth, (req, res) => {
  const { name, description, bannerColor } = req.body || {};
  if (!name || !name.trim()) return res.status(400).json({ error: 'Store name is required.' });

  const existing = db.prepare('SELECT id FROM stores WHERE owner_id = ?').get(req.userId);
  if (existing) return res.status(409).json({ error: 'You already have a store. Each account can run one store.' });

  const id = slugify(name);
  db.prepare(`
    INSERT INTO stores (id, owner_id, name, description, banner_color) VALUES (?, ?, ?, ?, ?)
  `).run(id, req.userId, name.trim(), description || '', bannerColor || '#8B6A4F');

  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(id);
  res.status(201).json({ store: serializeStore(store) });
});

// Update your own store's details
router.put('/:id', requireAuth, (req, res) => {
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(req.params.id);
  if (!store) return res.status(404).json({ error: 'Store not found.' });
  if (store.owner_id !== req.userId) return res.status(403).json({ error: 'You do not own this store.' });

  const { name, description, bannerColor } = req.body || {};
  db.prepare(`
    UPDATE stores SET name = COALESCE(?, name), description = COALESCE(?, description),
      banner_color = COALESCE(?, banner_color) WHERE id = ?
  `).run(name, description, bannerColor, store.id);

  res.json({ store: serializeStore(db.prepare('SELECT * FROM stores WHERE id = ?').get(store.id)) });
});

// Add a product to your own store
router.post('/:id/products', requireAuth, (req, res) => {
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(req.params.id);
  if (!store) return res.status(404).json({ error: 'Store not found.' });
  if (store.owner_id !== req.userId) return res.status(403).json({ error: 'You do not own this store.' });

  const { name, category, gsm, unit, priceKobo, color, description } = req.body || {};
  if (!name || !category || !unit || !priceKobo) {
    return res.status(400).json({ error: 'Name, category, unit and price are required.' });
  }
  const price = Number(priceKobo);
  if (!Number.isFinite(price) || price <= 0) {
    return res.status(400).json({ error: 'Price must be a positive number (in kobo).' });
  }

  const id = 'p_' + Math.random().toString(36).slice(2, 9);
  db.prepare(`
    INSERT INTO products (id, store_id, name, category, gsm, unit, price_kobo, color, description)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, store.id, name.trim(), category, gsm || '', unit.trim(), Math.round(price), color || '#EFEAE0', description || '');

  res.status(201).json({ product: db.prepare('SELECT * FROM products WHERE id = ?').get(id) });
});

// Orders placed against your own store (seller's order queue)
router.get('/:id/orders', requireAuth, (req, res) => {
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(req.params.id);
  if (!store) return res.status(404).json({ error: 'Store not found.' });
  if (store.owner_id !== req.userId) return res.status(403).json({ error: 'You do not own this store.' });

  const orders = db.prepare('SELECT * FROM orders WHERE store_id = ? ORDER BY created_at DESC').all(store.id);
  const result = orders.map(o => {
    const items = db.prepare('SELECT product_name, unit_price_kobo, quantity FROM order_items WHERE order_id = ?').all(o.id);
    const buyer = db.prepare('SELECT name, phone FROM users WHERE id = ?').get(o.user_id);
    const rider = o.rider_id ? db.prepare('SELECT name, vehicle FROM riders WHERE id = ?').get(o.rider_id) : null;
    return {
      id: o.id, status: o.status, totalKobo: o.total_kobo, createdAt: o.created_at,
      deliveryAddress: o.delivery_address, buyer, rider,
      items: items.map(i => ({ name: i.product_name, quantity: i.quantity, unitPriceKobo: i.unit_price_kobo }))
    };
  });
  res.json({ orders: result });
});

module.exports = router;
