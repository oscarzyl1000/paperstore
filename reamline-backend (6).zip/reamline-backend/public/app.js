/* ============================================================
   Reamline frontend — talks to the Express/SQLite API in ../src
   Auth token is kept in localStorage (this is a real deployed
   app, not a sandboxed artifact, so normal browser storage applies).
   ============================================================ */

const API = ''; // same-origin; set to your API's base URL if hosted separately

const state = {
  token: localStorage.getItem('reamline_token') || null,
  user: null,
  view: 'shop',
  authMode: 'login',
  authError: '',
  products: [],
  riders: [],
  orders: [],
  deliveries: [],
  paymentMethods: [],
  stores: [],           // marketplace directory
  viewingStoreId: null,  // set when browsing a single store's page under the Stores tab
  storeDetail: null,     // { store, products } for the store currently being viewed
  myStore: null,         // the logged-in user's own store, if any
  myStoreOrders: [],
  sellerError: '',
  cart: {},          // productId: qty  (client-side until checkout)
  cartOpen: false,
  checkoutOpen: false,
  checkoutStep: 'review',
  selectedPaymentId: null,
  lastOrders: [],
  riderFilter: 'all',
  shopFilter: 'all',
  shopStoreFilter: 'all',
  loading: false
};

function fmtKobo(k){ return '₦' + Math.round(k/100).toLocaleString('en-NG'); }
function initials(name){ return (name||'?').split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase(); }
function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(()=>t.classList.remove('show'), 2400);
}
function cartCount(){ return Object.values(state.cart).reduce((a,b)=>a+b,0); }
function cartTotalKobo(){
  return Object.entries(state.cart).reduce((sum,[id,qty])=>{
    const p = state.products.find(x=>x.id===id);
    return sum + (p ? p.price_kobo*qty : 0);
  },0);
}

/* ---------------- API helper ---------------- */
async function api(path, opts={}){
  const headers = { 'Content-Type':'application/json', ...(opts.headers||{}) };
  if(state.token) headers.Authorization = 'Bearer ' + state.token;
  const res = await fetch(API + path, { ...opts, headers });
  let data = null;
  try{ data = await res.json(); }catch(e){ /* e.g. 204 No Content */ }
  if(!res.ok){
    const err = new Error((data && data.error) || ('Request failed (' + res.status + ')'));
    err.status = res.status;
    throw err;
  }
  return data;
}

function setToken(token){
  state.token = token;
  if(token) localStorage.setItem('reamline_token', token);
  else localStorage.removeItem('reamline_token');
}

/* ---------------- Bootstrapping ---------------- */
async function boot(){
  render(true);
  try{
    state.products = (await api('/api/products')).products;
    state.riders = (await api('/api/riders')).riders;
  }catch(e){ console.error(e); }

  try{ state.stores = (await api('/api/stores')).stores; }catch(e){ console.error(e); }

  if(state.token){
    try{
      state.user = (await api('/api/auth/me')).user;
      await loadUserData();
    }catch(e){
      setToken(null); state.user = null;
    }
  }
  render();
}

async function loadUserData(){
  const [orders, deliveries, pms, mine] = await Promise.all([
    api('/api/orders'),
    api('/api/riders/my-deliveries'),
    api('/api/payment-methods'),
    api('/api/stores/mine')
  ]);
  state.orders = orders.orders;
  state.deliveries = deliveries.deliveries;
  state.paymentMethods = pms.paymentMethods;
  state.myStore = mine.store;
  if(state.myStore){
    try{ state.myStoreOrders = (await api('/api/stores/'+state.myStore.id+'/orders')).orders; }catch(e){ state.myStoreOrders = []; }
  } else {
    state.myStoreOrders = [];
  }
}

/* ================= RENDER ROOT ================= */
function render(booting){
  const app = document.getElementById('app');
  if(booting && !state.products.length){
    app.innerHTML = `<div class="login-wrap"><div class="sub mono">Loading Reamline…</div></div>`;
    return;
  }
  app.innerHTML = state.user ? renderApp() : renderLogin();
  attachHandlers();
}

/* ================= LOGIN VIEW ================= */
function renderLogin(){
  const isLogin = state.authMode === 'login';
  return `
  <div class="login-wrap">
    <div class="login-card">
      <div class="login-art">
        <div class="brand-mark"><div class="sq">R</div><span>Reamline</span></div>
        <div>
          <h1>Paper stock, ordered like clockwork.</h1>
          <p>Bond, kraft, cardstock and packaging paper — delivered across Lagos by our own rider fleet, with same-day dispatch on standard reams.</p>
        </div>
        <svg width="220" height="160" viewBox="0 0 220 160" fill="none" style="position:absolute; right:-30px; bottom:-30px; opacity:.9;">
          <rect x="20" y="120" width="180" height="14" rx="2" fill="#2C4A6E"/>
          <rect x="30" y="104" width="160" height="14" rx="2" fill="#33547A"/>
          <rect x="15" y="88" width="190" height="14" rx="2" fill="#3B5F87"/>
          <rect x="35" y="72" width="150" height="14" rx="2" fill="#436A93"/>
        </svg>
      </div>
      <div class="login-form">
        <div class="eyebrow">Customer Portal</div>
        <div class="form-toggle">
          <button data-auth="login" class="${isLogin?'active':''}">Log in</button>
          <button data-auth="signup" class="${!isLogin?'active':''}">Create account</button>
        </div>
        <div class="err" style="${state.authError?'display:block':''}">${state.authError||''}</div>
        <form id="authForm">
          ${!isLogin ? `
          <div class="field"><label>Full name</label><input type="text" name="name" placeholder="e.g. Femi Alabi" required /></div>
          <div class="field"><label>Company (optional)</label><input type="text" name="company" placeholder="Business name" /></div>
          ` : ''}
          <div class="field"><label>Email</label><input type="email" name="email" placeholder="you@company.com" required /></div>
          <div class="field"><label>Password</label><input type="password" name="password" placeholder="••••••••" required minlength="6" /></div>
          <button type="submit" class="btn stamp block" ${state.loading?'disabled':''}>${state.loading ? 'Please wait…' : (isLogin ? 'Log in' : 'Create account')}</button>
        </form>
        <div class="hint">Demo login — email <b>demo@reamline.com</b>, password <b>demo1234</b>.</div>
      </div>
    </div>
  </div>`;
}

/* ================= APP SHELL ================= */
function renderApp(){
  const tabs = [
    { id:'shop', label:'Shop' },
    { id:'stores', label:'Stores' },
    { id:'account', label:'Account & Payment' },
    { id:'riders', label:'Riders & Delivery' }
  ];
  return `
    <div class="topbar">
      <div class="brand-mark"><div class="sq">R</div><span>Reamline</span></div>
      <div class="tabs">
        ${tabs.map(t=>`<button class="tab ${state.view===t.id?'active':''}" data-view="${t.id}">${t.label}</button>`).join('')}
      </div>
      <div class="top-right">
        <button class="cart-btn" id="openCart">Cart ${cartCount()>0?`<span class="badge">${cartCount()}</span>`:''}</button>
        <div class="user-chip"><div class="av">${initials(state.user.name)}</div>${state.user.name.split(' ')[0]}</div>
        <button class="logout" id="logoutBtn">Log out</button>
      </div>
    </div>
    <div class="view">${renderView()}</div>
    <footer class="appfoot">REAMLINE PAPER SUPPLY CO. · LAGOS · LIVE API — DATA PERSISTS IN SQLITE</footer>
    ${renderCartDrawer()}
    ${renderCheckoutModal()}
  `;
}

function renderView(){
  if(state.view==='shop') return renderShop();
  if(state.view==='stores') return state.viewingStoreId ? renderStoreDetail() : renderStoresDirectory();
  if(state.view==='account') return renderAccount();
  if(state.view==='riders') return renderRiders();
  return '';
}

/* ================= SHOP ================= */
function renderShop(){
  const cats = [
    {id:'all', label:'All stock'},
    {id:'office', label:'Office & Copy'},
    {id:'craft', label:'Card & Craft'},
    {id:'packaging', label:'Packaging'}
  ];
  const list = state.products.filter(p =>
    (state.shopFilter==='all' || p.category===state.shopFilter) &&
    (state.shopStoreFilter==='all' || p.store_id===state.shopStoreFilter)
  );
  return `
    <div class="view-head">
      <div class="eyebrow">Ream by ream</div>
      <h2>Shop paper stock</h2>
      <p>From Reamline Direct and independent sellers on the marketplace. Add items from any store to one cart — checkout splits and assigns a rider per seller automatically.</p>
    </div>
    <div class="shop-toolbar">
      ${cats.map(c=>`<button class="chip-filter ${state.shopFilter===c.id?'active':''}" data-cat="${c.id}">${c.label}</button>`).join('')}
    </div>
    <div class="shop-toolbar">
      <button class="chip-filter store-chip ${state.shopStoreFilter==='all'?'active':''}" data-storefilter="all">All sellers</button>
      ${state.stores.map(s=>`<button class="chip-filter store-chip ${state.shopStoreFilter===s.id?'active':''}" data-storefilter="${s.id}">${s.name}</button>`).join('')}
    </div>
    <div class="grid">
      ${list.map(p=>{
        const qty = state.cart[p.id]||0;
        const sheets = Math.min(qty,6);
        return `
        <div class="pcard">
          <div class="swatch" style="--swatch-color:${p.color}">
            <span class="gsm">${p.gsm}</span>
            <div class="fold"></div>
          </div>
          <div class="pinfo">
            ${p.store ? `<button class="store-badge" data-openstore="${p.store.id}" style="--sb:${p.store.bannerColor}">${p.store.name}</button>` : ''}
            <h4>${p.name}</h4>
            <div class="desc">${p.description}</div>
            <div class="price-row">
              <div class="price">${fmtKobo(p.price_kobo)} <small>/ ${p.unit}</small></div>
            </div>
            <div class="pfoot">
              <div class="stack-vis">${Array.from({length:sheets}).map(()=>'<div class="sheet"></div>').join('') || '<div style="height:3px"></div>'}</div>
              <div class="stepper">
                <button data-dec="${p.id}">−</button>
                <div class="qty">${qty}</div>
                <button data-inc="${p.id}">+</button>
              </div>
            </div>
            <button class="btn secondary small" style="margin-top:8px" data-add="${p.id}">${qty>0?'Update cart':'Add to cart'}</button>
          </div>
        </div>`;
      }).join('')}
    </div>
  `;
}

/* ================= STORES DIRECTORY ================= */
function renderStoresDirectory(){
  return `
    <div class="view-head">
      <div class="eyebrow">Marketplace</div>
      <h2>Sellers on Reamline</h2>
      <p>Independent stores selling paper stock alongside Reamline Direct. Open a store yourself from Account & Payment.</p>
    </div>
    <div class="store-grid">
      ${state.stores.map(s=>`
        <button class="store-card" data-openstore="${s.id}" style="--sb:${s.bannerColor}">
          <div class="store-banner"></div>
          <div class="store-card-body">
            <h4>${s.name}</h4>
            <div class="desc">${s.description||''}</div>
            <div class="store-meta">${s.productCount} product${s.productCount===1?'':'s'} · run by ${s.ownerName||'a seller'}</div>
          </div>
        </button>
      `).join('')}
    </div>
  `;
}

function renderStoreDetail(){
  const d = state.storeDetail;
  if(!d) return `<div class="sub">Loading store…</div>`;
  return `
    <button class="btn secondary small" id="backToStores" style="margin-bottom:18px">← All stores</button>
    <div class="view-head">
      <div class="eyebrow" style="color:${d.store.bannerColor}">Seller store</div>
      <h2>${d.store.name}</h2>
      <p>${d.store.description||''}</p>
    </div>
    <div class="grid">
      ${d.products.map(p=>{
        const qty = state.cart[p.id]||0;
        const sheets = Math.min(qty,6);
        return `
        <div class="pcard">
          <div class="swatch" style="--swatch-color:${p.color}">
            <span class="gsm">${p.gsm}</span>
            <div class="fold"></div>
          </div>
          <div class="pinfo">
            <h4>${p.name}</h4>
            <div class="desc">${p.description}</div>
            <div class="price-row">
              <div class="price">${fmtKobo(p.price_kobo)} <small>/ ${p.unit}</small></div>
            </div>
            <div class="pfoot">
              <div class="stack-vis">${Array.from({length:sheets}).map(()=>'<div class="sheet"></div>').join('') || '<div style="height:3px"></div>'}</div>
              <div class="stepper">
                <button data-dec="${p.id}">−</button>
                <div class="qty">${qty}</div>
                <button data-inc="${p.id}">+</button>
              </div>
            </div>
            <button class="btn secondary small" style="margin-top:8px" data-add="${p.id}">${qty>0?'Update cart':'Add to cart'}</button>
          </div>
        </div>`;
      }).join('') || '<div class="sub">This store has no products listed yet.</div>'}
    </div>
  `;
}

/* ================= ACCOUNT ================= */
function renderAccount(){
  const u = state.user;
  const statusClass = s => 'status-' + s.replace(/ /g,'-');
  return `
    <div class="view-head">
      <div class="eyebrow">Your details</div>
      <h2>Account & payment</h2>
      <p>Manage your delivery details, saved payment methods and order history.</p>
    </div>
    <div class="two-col">
      <div>
        <div class="panel">
          <div class="profile-head">
            <div class="av">${initials(u.name)}</div>
            <div>
              <h3 style="font-size:18px">${u.name}</h3>
              <div class="sub" style="margin-bottom:0">${u.company||'Individual account'}</div>
            </div>
          </div>
          <form id="profileForm" class="kv-grid">
            <div class="field" style="margin-bottom:0"><label>Email</label><input value="${u.email}" disabled /></div>
            <div class="field" style="margin-bottom:0"><label>Phone</label><input name="phone" value="${u.phone||''}" placeholder="080..." /></div>
            <div class="field" style="grid-column:1/-1; margin-bottom:0"><label>Delivery address</label><input name="address" value="${u.address||''}" placeholder="Street, area, city" required /></div>
            <div style="grid-column:1/-1">
              <button type="submit" class="btn secondary small" style="margin-top:6px">Save details</button>
            </div>
          </form>
        </div>

        <div class="panel">
          <h3>Order history</h3>
          <div class="sub">${state.orders.length} orders placed</div>
          ${state.orders.map(o=>`
            <div class="order-row">
              <div class="order-id">${o.id}<br/><span style="color:var(--charcoal-soft)">${new Date(o.createdAt).toLocaleDateString('en-GB',{day:'2-digit',month:'short'})}</span></div>
              <div>
                <div style="font-size:13.5px;font-weight:500">${o.items.map(i=>i.name+' x'+i.quantity).join(', ')}</div>
                <div style="font-size:11.5px;color:var(--charcoal-soft);margin-top:2px">Rider: ${o.rider ? o.rider.name : 'Unassigned'}</div>
              </div>
              <div class="mono" style="font-weight:600">${fmtKobo(o.totalKobo)}</div>
              <div class="status-pill ${statusClass(o.status)}">${o.status}</div>
            </div>
          `).join('') || '<div class="sub">No orders yet — head to Shop to place your first order.</div>'}
        </div>
      </div>

      <div>
        <div class="panel">
          <h3>Payment methods</h3>
          <div class="sub">Saved cards for faster checkout</div>
          ${state.paymentMethods.map(pm=>`
            <div class="paycard">
              <div class="left">
                <div class="cardchip">${pm.brand.slice(0,4).toUpperCase()}</div>
                <div>
                  <div class="num">•••• •••• •••• ${pm.last4} ${pm.is_default?'<span class="default-tag">Default</span>':''}</div>
                  <div class="exp">Expires ${pm.exp}</div>
                </div>
              </div>
              <button class="remove-x" data-removepm="${pm.id}">Remove</button>
            </div>
          `).join('') || '<div class="sub">No cards saved yet.</div>'}
          <form id="addCardForm" style="margin-top:14px; border-top:1px solid var(--line); padding-top:14px;">
            <div class="field"><label>Card number</label><input required maxlength="19" placeholder="4821 0099 0000 0000" name="num" /></div>
            <div style="display:flex; gap:10px;">
              <div class="field" style="flex:1"><label>Expiry</label><input required placeholder="MM/YY" name="exp" maxlength="5" /></div>
              <div class="field" style="flex:1"><label>CVV</label><input required placeholder="•••" name="cvv" maxlength="3" /></div>
            </div>
            <button type="submit" class="btn secondary block">Add payment method</button>
          </form>
        </div>

        ${renderSellerPanel()}
      </div>
    </div>
  `;
}

/* ---- Seller panel (inside Account) ---- */
function renderSellerPanel(){
  if(!state.myStore){
    return `
      <div class="panel">
        <h3>Sell on Reamline</h3>
        <div class="sub">Open your own store on the marketplace — customers will find your products in Shop and Stores.</div>
        <div class="err" style="${state.sellerError?'display:block':''}">${state.sellerError||''}</div>
        <form id="openStoreForm">
          <div class="field"><label>Store name</label><input required name="name" placeholder="e.g. Chidi's Paper House" /></div>
          <div class="field"><label>Description</label><input name="description" placeholder="What do you sell?" /></div>
          <button type="submit" class="btn secondary block">Open my store</button>
        </form>
      </div>`;
  }

  const s = state.myStore;
  const myProducts = state.products.filter(p=>p.store_id===s.id);
  return `
    <div class="panel">
      <h3>My store — ${s.name}</h3>
      <div class="sub">${s.productCount} product${s.productCount===1?'':'s'} listed · visible to all customers</div>

      <div style="margin-bottom:16px;">
        ${myProducts.map(p=>`
          <div class="paycard">
            <div class="left">
              <div class="cardchip" style="background:${p.color}; color:var(--charcoal)">${p.gsm||''}</div>
              <div>
                <div class="num" style="font-size:13px">${p.name}</div>
                <div class="exp">${fmtKobo(p.price_kobo)} / ${p.unit}</div>
              </div>
            </div>
            <button class="remove-x" data-removeproduct="${p.id}">Remove</button>
          </div>
        `).join('') || '<div class="sub">No products listed yet — add your first one below.</div>'}
      </div>

      <form id="addProductForm" style="border-top:1px solid var(--line); padding-top:14px;">
        <div class="field"><label>Product name</label><input required name="name" placeholder="e.g. A5 Recycled Notepad Paper" /></div>
        <div style="display:flex; gap:10px;">
          <div class="field" style="flex:1">
            <label>Category</label>
            <select name="category" required>
              <option value="office">Office & Copy</option>
              <option value="craft">Card & Craft</option>
              <option value="packaging">Packaging</option>
            </select>
          </div>
          <div class="field" style="flex:1"><label>GSM</label><input name="gsm" placeholder="e.g. 80gsm" /></div>
        </div>
        <div style="display:flex; gap:10px;">
          <div class="field" style="flex:1"><label>Unit</label><input required name="unit" placeholder="e.g. ream of 500" /></div>
          <div class="field" style="flex:1"><label>Price (₦)</label><input required type="number" min="1" name="priceNaira" placeholder="8200" /></div>
        </div>
        <div class="field"><label>Description</label><input name="description" placeholder="Short product description" /></div>
        <button type="submit" class="btn secondary block">Add product</button>
      </form>
    </div>

    <div class="panel">
      <h3>Orders for my store</h3>
      <div class="sub">${state.myStoreOrders.length} order${state.myStoreOrders.length===1?'':'s'} received</div>
      ${state.myStoreOrders.map(o=>`
        <div class="order-row">
          <div class="order-id">${o.id}<br/><span style="color:var(--charcoal-soft)">${new Date(o.createdAt).toLocaleDateString('en-GB',{day:'2-digit',month:'short'})}</span></div>
          <div>
            <div style="font-size:13.5px;font-weight:500">${o.items.map(i=>i.name+' x'+i.quantity).join(', ')}</div>
            <div style="font-size:11.5px;color:var(--charcoal-soft);margin-top:2px">Buyer: ${o.buyer ? o.buyer.name : 'Unknown'} · Rider: ${o.rider ? o.rider.name : 'Unassigned'}</div>
          </div>
          <div class="mono" style="font-weight:600">${fmtKobo(o.totalKobo)}</div>
          <div class="status-pill status-${o.status.replace(/ /g,'-')}">${o.status}</div>
        </div>
      `).join('') || '<div class="sub">No orders yet.</div>'}
    </div>
  `;
}

/* ================= RIDERS ================= */
function renderRiders(){
  const filtered = state.riders.filter(r => state.riderFilter==='all' || r.status===state.riderFilter);
  const steps = ['Processing','Out for delivery','Delivered'];
  const stepIndex = { 'Processing':0, 'Out for delivery':1, 'Delivered':2 };
  return `
    <div class="view-head">
      <div class="eyebrow">Dispatch</div>
      <h2>Riders & delivery</h2>
      <p>Track who's carrying your order, and see the fleet currently on shift across Lagos.</p>
    </div>

    <div class="panel">
      <h3>Your live deliveries</h3>
      <div class="sub">Orders currently in progress</div>
      ${state.deliveries.map(d=>`
        <div class="track-row">
          <div class="track-top">
            <div>
              <div style="font-weight:600; font-size:14.5px;">${d.order_id}</div>
              <div style="font-size:12px; color:var(--charcoal-soft); margin-top:3px;">Assigned rider: <b>${d.rider_name || 'Unassigned'}</b>${d.zone ? ' · '+d.zone : ''}</div>
            </div>
            <div class="status-pill status-${d.status.replace(/ /g,'-')}">${d.status}</div>
          </div>
          <div class="track-steps">
            ${steps.map((s,i)=>`
              <div class="tstep ${i<stepIndex[d.status]?'done':''} ${i===stepIndex[d.status]?'current':''}">
                <div class="circle">${i<stepIndex[d.status]?'✓':i+1}</div>
                <div class="label">${s}</div>
              </div>
            `).join('')}
          </div>
          ${d.status!=='Delivered' ? `<button class="btn secondary small" style="margin-top:14px" data-advance="${d.order_id}" data-next="${steps[stepIndex[d.status]+1]}">Simulate: mark "${steps[stepIndex[d.status]+1]}"</button>` : ''}
        </div>
      `).join('') || '<div class="sub">No active deliveries right now.</div>'}
    </div>

    <div class="panel">
      <h3>Rider fleet</h3>
      <div class="sub">Available riders are assigned automatically at checkout</div>
      <div class="shop-toolbar">
        <button class="chip-filter ${state.riderFilter==='all'?'active':''}" data-riderfilter="all">All riders</button>
        <button class="chip-filter ${state.riderFilter==='available'?'active':''}" data-riderfilter="available">Available</button>
        <button class="chip-filter ${state.riderFilter==='busy'?'active':''}" data-riderfilter="busy">On delivery</button>
      </div>
      <div class="rider-grid">
        ${filtered.map(r=>`
          <div class="rider-card">
            <div class="rider-av">${initials(r.name)}</div>
            <div>
              <div class="rider-name">${r.name}</div>
              <div class="rider-meta">${r.vehicle} · ${r.zone}</div>
              <div class="rider-stat"><span class="dot ${r.status==='available'?'avail':'busy'}"></span>${r.status==='available'?'Available now':'On a delivery'}</div>
              <div class="rider-stat">${r.deliveries} completed deliveries</div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

/* ================= CART DRAWER ================= */
function renderCartDrawer(){
  const items = Object.entries(state.cart).filter(([,q])=>q>0);
  const deliveryKobo = items.length ? 150000 : 0;
  return `
    <div class="overlay ${state.cartOpen?'open':''}" id="cartOverlay"></div>
    <div class="drawer ${state.cartOpen?'open':''}">
      <div class="drawer-head"><h3 style="font-size:17px">Your cart</h3><button class="close-x" id="closeCart">×</button></div>
      <div class="drawer-body">
        ${items.length===0 ? '<div class="empty-cart">Your cart is empty.<br/>Add some paper stock to get started.</div>' :
          items.map(([id,qty])=>{
            const p = state.products.find(x=>x.id===id);
            return `
            <div class="cart-item">
              <div class="sw" style="background:${p.color}"></div>
              <div class="ci-info">
                <div class="ci-name">${p.name}</div>
                <div class="ci-meta">${qty} × ${fmtKobo(p.price_kobo)} · ${p.unit}</div>
              </div>
              <div class="stepper">
                <button data-dec="${id}">−</button>
                <div class="qty">${qty}</div>
                <button data-inc="${id}">+</button>
              </div>
            </div>`;
          }).join('')
        }
      </div>
      ${items.length>0 ? `
      <div class="drawer-foot">
        <div class="sum-row"><span>Subtotal</span><span class="mono">${fmtKobo(cartTotalKobo())}</span></div>
        <div class="sum-row"><span>Delivery</span><span class="mono">${fmtKobo(deliveryKobo)}</span></div>
        <div class="sum-row total"><span>Total</span><span class="mono">${fmtKobo(cartTotalKobo()+deliveryKobo)}</span></div>
        <button class="btn stamp block" id="beginCheckout">Checkout</button>
      </div>` : ''}
    </div>
  `;
}

/* ================= CHECKOUT MODAL ================= */
function renderCheckoutModal(){
  if(!state.checkoutOpen) return `<div class="modal-bg"></div>`;
  const items = Object.entries(state.cart).filter(([,q])=>q>0);
  const deliveryKobo = 150000;
  const total = cartTotalKobo()+deliveryKobo;

  let body = '';
  if(state.checkoutStep==='review'){
    body = `
      <div class="modal-body">
        <h3 style="font-size:15px;margin-bottom:10px;">Order summary</h3>
        ${items.map(([id,qty])=>{
          const p = state.products.find(x=>x.id===id);
          return `<div class="receipt-line"><span>${p.name} × ${qty}</span><span>${fmtKobo(p.price_kobo*qty)}</span></div>`;
        }).join('')}
        <div class="receipt-line"><span>Delivery</span><span>${fmtKobo(deliveryKobo)}</span></div>
        <div class="receipt-line tot"><span>Total</span><span>${fmtKobo(total)}</span></div>
        <div style="margin-top:16px; font-size:12.5px; color:var(--charcoal-soft);">
          Delivering to <b>${state.user.address || 'no address on file'}</b>
          ${!state.user.address ? '<br/><span style="color:var(--stamp)">Add a delivery address under Account before checking out.</span>' : ''}
        </div>
        <button class="btn stamp block" style="margin-top:18px" id="toPayment" ${!state.user.address?'disabled':''}>Continue to payment</button>
      </div>`;
  } else if(state.checkoutStep==='payment'){
    body = `
      <div class="modal-body">
        <h3 style="font-size:15px;margin-bottom:10px;">Choose payment method</h3>
        ${state.paymentMethods.map(pm=>`
          <div class="radio-opt ${state.selectedPaymentId==String(pm.id)?'sel':''}" data-selectpm="${pm.id}">
            <div class="cardchip">${pm.brand.slice(0,4).toUpperCase()}</div>
            <div>•••• ${pm.last4} — expires ${pm.exp}</div>
          </div>
        `).join('')}
        <div class="radio-opt ${state.selectedPaymentId==='cod'?'sel':''}" data-selectpm="cod">
          <div class="cardchip" style="background:var(--kraft)">COD</div>
          <div>Pay rider on delivery (cash)</div>
        </div>
        <button class="btn stamp block" style="margin-top:14px" id="placeOrder" ${!state.selectedPaymentId||state.loading?'disabled':''}>${state.loading?'Placing order…':'Place order — '+fmtKobo(total)}</button>
      </div>`;
  } else if(state.checkoutStep==='done'){
    const orders = state.lastOrders;
    const multi = orders.length > 1;
    body = `
      <div class="modal-body" style="text-align:center; padding:32px 24px;">
        <div style="width:46px;height:46px;border-radius:50%;background:var(--ok);color:#fff;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:20px;">✓</div>
        <h3 style="font-size:17px;">${multi ? orders.length+' orders placed' : 'Order placed'}</h3>
        ${multi ? `<p style="font-size:12.5px;color:var(--charcoal-soft);margin-top:6px;">Your cart spanned ${orders.length} sellers, so it was split into separate orders — one per store.</p>` : ''}
        <div style="text-align:left; margin-top:14px;">
          ${orders.map(o=>`
            <div style="border:1px solid var(--line); padding:12px 14px; margin-bottom:8px; border-radius:2px;">
              <div style="font-size:13px; font-weight:600;">${o.id} ${o.store ? '· '+o.store.name : ''}</div>
              <div style="font-size:12px; color:var(--charcoal-soft); margin-top:3px;">
                Assigned to <b>${o.rider ? o.rider.name : 'a rider'}</b>${o.rider ? ' ('+o.rider.vehicle+'), '+o.rider.zone : ''}
              </div>
            </div>
          `).join('')}
        </div>
        <p style="font-size:12px;color:var(--charcoal-soft);margin-top:4px;">Track progress under Riders & Delivery.</p>
        <button class="btn stamp block" style="margin-top:16px" id="closeCheckoutDone">Done</button>
      </div>`;
  }

  return `
    <div class="modal-bg open">
      <div class="modal">
        <div class="modal-head">
          <h3 style="font-size:16px">${state.checkoutStep==='done' ? 'Confirmation' : 'Checkout'}</h3>
          <button class="close-x" id="closeCheckout">×</button>
        </div>
        ${body}
      </div>
    </div>
  `;
}

/* ================= HANDLERS ================= */
function attachHandlers(){
  // --- Auth ---
  document.querySelectorAll('[data-auth]').forEach(b=>b.onclick=()=>{
    state.authMode = b.dataset.auth; state.authError=''; render();
  });
  const authForm = document.getElementById('authForm');
  if(authForm) authForm.onsubmit = async (e)=>{
    e.preventDefault();
    const fd = new FormData(authForm);
    const payload = Object.fromEntries(fd.entries());
    state.loading = true; state.authError=''; render();
    try{
      const path = state.authMode==='login' ? '/api/auth/login' : '/api/auth/signup';
      const data = await api(path, { method:'POST', body: JSON.stringify(payload) });
      setToken(data.token);
      state.user = data.user;
      await loadUserData();
      toast(state.authMode==='login' ? 'Welcome back, '+data.user.name.split(' ')[0]+'.' : 'Account created — welcome, '+data.user.name.split(' ')[0]+'.');
    }catch(err){
      state.authError = err.message;
    }finally{
      state.loading = false; render();
    }
  };

  if(!state.user) return;

  // --- Logout ---
  document.getElementById('logoutBtn').onclick = ()=>{
    setToken(null); state.user=null; state.cart={}; state.orders=[]; state.deliveries=[]; state.paymentMethods=[]; render();
  };

  // --- Tabs ---
  document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{
    state.view=b.dataset.view;
    if(state.view==='stores'){ state.viewingStoreId=null; state.storeDetail=null; }
    render();
  });

  // --- Filters ---
  document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{ state.shopFilter=b.dataset.cat; render(); });
  document.querySelectorAll('[data-storefilter]').forEach(b=>b.onclick=()=>{ state.shopStoreFilter=b.dataset.storefilter; render(); });
  document.querySelectorAll('[data-riderfilter]').forEach(b=>b.onclick=()=>{ state.riderFilter=b.dataset.riderfilter; render(); });

  // --- Store navigation (from Shop badges or the Stores directory) ---
  document.querySelectorAll('[data-openstore]').forEach(b=>b.onclick=async ()=>{
    const id = b.dataset.openstore;
    state.view='stores'; state.viewingStoreId=id; state.storeDetail=null; render();
    try{
      state.storeDetail = await api('/api/stores/'+id);
      render();
    }catch(err){ toast(err.message); }
  });
  const backToStores = document.getElementById('backToStores');
  if(backToStores) backToStores.onclick = ()=>{ state.viewingStoreId=null; state.storeDetail=null; render(); };

  // --- Qty steppers ---
  document.querySelectorAll('[data-inc]').forEach(b=>b.onclick=()=>{
    const id=b.dataset.inc; state.cart[id]=(state.cart[id]||0)+1; render();
  });
  document.querySelectorAll('[data-dec]').forEach(b=>b.onclick=()=>{
    const id=b.dataset.dec; state.cart[id]=Math.max(0,(state.cart[id]||0)-1); render();
  });
  document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{
    const id=b.dataset.add;
    if(!state.cart[id]) state.cart[id]=1;
    const p = state.products.find(x=>x.id===id);
    toast(p.name+' added to cart.');
    render();
  });

  // --- Cart drawer ---
  const openCart = document.getElementById('openCart');
  if(openCart) openCart.onclick = ()=>{ state.cartOpen=true; render(); };
  const closeCart = document.getElementById('closeCart');
  if(closeCart) closeCart.onclick = ()=>{ state.cartOpen=false; render(); };
  const cartOverlay = document.getElementById('cartOverlay');
  if(cartOverlay) cartOverlay.onclick = ()=>{ state.cartOpen=false; render(); };

  // --- Checkout flow ---
  const beginCheckout = document.getElementById('beginCheckout');
  if(beginCheckout) beginCheckout.onclick = ()=>{
    state.cartOpen=false; state.checkoutOpen=true; state.checkoutStep='review'; state.selectedPaymentId=null; render();
  };
  const closeCheckout = document.getElementById('closeCheckout');
  if(closeCheckout) closeCheckout.onclick = ()=>{ state.checkoutOpen=false; render(); };
  const toPayment = document.getElementById('toPayment');
  if(toPayment) toPayment.onclick = ()=>{ state.checkoutStep='payment'; render(); };
  document.querySelectorAll('[data-selectpm]').forEach(el=>el.onclick=()=>{
    state.selectedPaymentId = el.dataset.selectpm; render();
  });
  const placeOrder = document.getElementById('placeOrder');
  if(placeOrder) placeOrder.onclick = async ()=>{
    state.loading = true; render();
    try{
      const items = Object.entries(state.cart).filter(([,q])=>q>0).map(([productId,quantity])=>({productId,quantity}));
      const data = await api('/api/orders', { method:'POST', body: JSON.stringify({ items, paymentMethodId: state.selectedPaymentId }) });
      state.lastOrders = data.orders;
      state.cart = {};
      await Promise.all([
        api('/api/riders').then(r=>state.riders=r.riders),
      ]);
      await loadUserData();
      state.checkoutStep='done';
    }catch(err){
      toast(err.message);
    }finally{
      state.loading = false; render();
    }
  };
  const closeDone = document.getElementById('closeCheckoutDone');
  if(closeDone) closeDone.onclick = ()=>{ state.checkoutOpen=false; state.checkoutStep='review'; render(); };

  // --- Account: profile ---
  const profileForm = document.getElementById('profileForm');
  if(profileForm) profileForm.onsubmit = async (e)=>{
    e.preventDefault();
    const fd = new FormData(profileForm);
    try{
      const data = await api('/api/auth/me', { method:'PUT', body: JSON.stringify(Object.fromEntries(fd.entries())) });
      state.user = data.user;
      toast('Details saved.');
      render();
    }catch(err){ toast(err.message); }
  };

  // --- Account: payment methods ---
  document.querySelectorAll('[data-removepm]').forEach(b=>b.onclick=async ()=>{
    try{
      await api('/api/payment-methods/'+b.dataset.removepm, { method:'DELETE' });
      state.paymentMethods = state.paymentMethods.filter(p=>String(p.id)!==b.dataset.removepm);
      render();
    }catch(err){ toast(err.message); }
  });
  const addCardForm = document.getElementById('addCardForm');
  if(addCardForm) addCardForm.onsubmit = async (e)=>{
    e.preventDefault();
    const fd = new FormData(addCardForm);
    try{
      const data = await api('/api/payment-methods', { method:'POST', body: JSON.stringify({ number: fd.get('num'), exp: fd.get('exp'), brand:'Card' }) });
      state.paymentMethods.push(data.paymentMethod);
      toast('Payment method added.');
      render();
    }catch(err){ toast(err.message); }
  };

  // --- Seller: open a store ---
  const openStoreForm = document.getElementById('openStoreForm');
  if(openStoreForm) openStoreForm.onsubmit = async (e)=>{
    e.preventDefault();
    const fd = new FormData(openStoreForm);
    try{
      const data = await api('/api/stores', { method:'POST', body: JSON.stringify({ name: fd.get('name'), description: fd.get('description') }) });
      state.myStore = data.store;
      state.sellerError = '';
      state.stores = (await api('/api/stores')).stores;
      toast('Your store is live — start listing products.');
      render();
    }catch(err){ state.sellerError = err.message; render(); }
  };

  // --- Seller: add a product to my store ---
  const addProductForm = document.getElementById('addProductForm');
  if(addProductForm) addProductForm.onsubmit = async (e)=>{
    e.preventDefault();
    const fd = new FormData(addProductForm);
    try{
      await api('/api/stores/'+state.myStore.id+'/products', {
        method:'POST',
        body: JSON.stringify({
          name: fd.get('name'), category: fd.get('category'), gsm: fd.get('gsm'),
          unit: fd.get('unit'), priceKobo: Math.round(Number(fd.get('priceNaira'))*100),
          description: fd.get('description'), color: '#EFEAE0'
        })
      });
      state.products = (await api('/api/products')).products;
      const mine = await api('/api/stores/mine');
      state.myStore = mine.store;
      toast('Product added to your store.');
      render();
    }catch(err){ toast(err.message); }
  };

  // --- Seller: remove a product ---
  document.querySelectorAll('[data-removeproduct]').forEach(b=>b.onclick=async ()=>{
    try{
      await api('/api/products/'+b.dataset.removeproduct, { method:'DELETE' });
      state.products = (await api('/api/products')).products;
      const mine = await api('/api/stores/mine');
      state.myStore = mine.store;
      render();
    }catch(err){ toast(err.message); }
  });

  // --- Riders: simulate status advance (demo of the delivery lifecycle) ---
  document.querySelectorAll('[data-advance]').forEach(b=>b.onclick=async ()=>{
    try{
      await api('/api/orders/'+b.dataset.advance+'/status', { method:'PUT', body: JSON.stringify({ status: b.dataset.next }) });
      await loadUserData();
      state.riders = (await api('/api/riders')).riders;
      render();
    }catch(err){ toast(err.message); }
  });
}

boot();
