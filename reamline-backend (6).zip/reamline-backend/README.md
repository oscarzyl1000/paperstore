# Reamline — Paper Supply Marketplace Backend

A real Express + SQLite backend for a multi-vendor paper-supply marketplace:
customer login, browsing across Reamline's own stock *and* independent
sellers' stores, cart/checkout that splits across sellers automatically,
saved payment methods, order history, a seller dashboard, and a rider/
delivery tracking system. Includes a static frontend that talks to the API
(served from `public/`).

## Stack

- **Server:** Node.js + Express
- **Database:** SQLite via `better-sqlite3` (single file, no separate DB server to run)
- **Auth:** email/password with `bcryptjs` hashing + JWT session tokens
- **Frontend:** plain HTML/CSS/JS in `public/`, served by the same Express app

## Project layout

```
reamline-backend/
├── src/
│   ├── server.js         # Express app entry point
│   ├── db.js              # SQLite schema + demo data seeding
│   ├── middleware/auth.js # JWT verification
│   └── routes/            # auth, products, orders, payments, riders
├── public/
│   ├── index.html
│   ├── app.js              # frontend logic — calls the API
│   └── styles.css
├── data/                   # SQLite database file lives here (git-ignored)
├── .env.example
└── package.json
```

## Run it locally

```bash
npm install
cp .env.example .env
# open .env and set JWT_SECRET to a long random string
npm start
```

The app is served at **http://localhost:4000** — the API under `/api/*`
and the frontend at `/`. The database is created automatically on first run
and seeded with:

- Demo customer login: **demo@reamline.com** / **demo1234**
- Demo seller logins: **chidi@lekkicraft.com** / **seller1234** (Lekki Craft Papers),
  **grace@naijapack.com** / **seller1234** (Naija Packaging Co)
- 3 seeded stores (including Reamline's own), 9 products spread across them, 6 riders

Delete `data/reamline.db` at any time to reset to a clean seeded state.

## API overview

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/signup` | – | Create an account, returns a JWT |
| POST | `/api/auth/login` | – | Log in, returns a JWT |
| GET | `/api/auth/me` | ✓ | Current user profile |
| PUT | `/api/auth/me` | ✓ | Update name/company/phone/address |
| GET | `/api/products` | – | List products (`?category=office\|craft\|packaging`, `?store=<storeId>`), each with its `store` |
| PUT | `/api/products/:id` | ✓ (owner) | Edit one of your own store's products |
| DELETE | `/api/products/:id` | ✓ (owner) | Deactivate one of your own store's products |
| GET | `/api/stores` | – | Browse the seller directory |
| GET | `/api/stores/:id` | – | A store's page — details + its active products |
| GET | `/api/stores/mine` | ✓ | Your own store, if you have one |
| POST | `/api/stores` | ✓ | Open a store for your account (one per account) |
| PUT | `/api/stores/:id` | ✓ (owner) | Update your store's name/description/colour |
| POST | `/api/stores/:id/products` | ✓ (owner) | List a new product under your store |
| GET | `/api/stores/:id/orders` | ✓ (owner) | Orders placed against your store, with buyer + rider info |
| GET | `/api/payment-methods` | ✓ | List saved cards |
| POST | `/api/payment-methods` | ✓ | Add a card (demo only — see note below) |
| DELETE | `/api/payment-methods/:id` | ✓ | Remove a card |
| GET | `/api/orders` | ✓ | List your orders |
| POST | `/api/orders` | ✓ | Checkout — `{ items:[{productId,quantity}], paymentMethodId }` |
| PUT | `/api/orders/:id/status` | ✓ | Advance delivery status (demo — normally rider-side) |
| GET | `/api/riders` | – | List the rider fleet (`?status=available\|busy`) |
| GET | `/api/riders/my-deliveries` | ✓ | Your active (non-delivered) orders with rider info |

All prices are stored in **kobo** (smallest currency unit) to avoid float
rounding issues; the frontend formats them as naira.

### How multi-vendor checkout works

A shopper's cart can hold products from several different sellers at once.
`POST /api/orders` groups the cart's line items by which store sells them and
creates **one order per store**, each with its own subtotal, delivery fee,
and auto-assigned rider — mirroring how a real marketplace settles and
fulfills orders per seller rather than as one lump order. The endpoint
returns an array (`{ orders: [...] }`) for this reason, even when the cart
only touched one store.

### Becoming a seller

Any logged-in account can open a store (`POST /api/stores`) — there's no
separate "seller" signup flow or role flag; a customer account and a seller
account are the same thing, the way many real marketplaces work. Each
account can run exactly one store. Once a store exists, its owner can list
products under it and see incoming orders filtered to just their store via
`GET /api/stores/:id/orders` — other sellers cannot see or edit each other's
listings (enforced server-side by checking `stores.owner_id` against the
requester on every write).

## Important before going to production

1. **Payments are mocked.** `POST /api/payment-methods` stores only a brand
   and last-4 digits — it never touches a real card number meaningfully. Wire
   up a real processor (Paystack, Flutterwave, Stripe) and store only the
   token/reference it gives you, never raw card data.
2. **Set a real `JWT_SECRET`.** The `.env.example` placeholder is not safe to
   ship — generate one with `openssl rand -hex 32`.
3. **Swap SQLite for a hosted database** if you expect concurrent write load
   beyond a single small server (SQLite is genuinely fine for a lot of small
   businesses, but doesn't scale horizontally). Postgres is a natural next
   step — the query layer is small enough to port by hand.
4. **Put HTTPS in front of it** (most hosts below do this for you) — don't
   run auth over plain HTTP.
5. **Lock down `CORS_ORIGIN`** to your real frontend domain instead of `*`.

## Deploying

Any Node host works since this is a single process with a file-based DB.
Straightforward options:

- **Render / Railway / Fly.io** — connect the repo, set `JWT_SECRET` (and
  optionally `CORS_ORIGIN`) as environment variables, add a persistent disk
  mounted at `data/` so the SQLite file survives redeploys, deploy.
- **A VPS (DigitalOcean, Hetzner, etc.)** — `git clone`, `npm install --omit=dev`,
  set up `.env`, run behind `pm2` or `systemd`, put Nginx + Let's Encrypt in front.

## Extending it

- The rider "Simulate: mark …" button on the Riders tab calls
  `PUT /api/orders/:id/status` directly from the customer view, standing in
  for what would normally be a separate rider-facing app or a webhook from
  your dispatch system.
- Rider auto-assignment currently picks the least-busy `available` rider at
  checkout (`orders.js`). A real fleet would probably factor in proximity —
  that's the natural next upgrade if you add rider geolocation.
